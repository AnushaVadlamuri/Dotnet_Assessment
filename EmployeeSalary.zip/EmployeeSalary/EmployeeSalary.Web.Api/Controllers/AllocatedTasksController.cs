﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EmployeeSalary.Web.Api.Models;

namespace EmployeeSalary.Web.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AllocatedTasksController : ControllerBase
    {
        private readonly FSPersonnelContext _context;

        public AllocatedTasksController(FSPersonnelContext context)
        {
            _context = context;
        }

        // GET: api/AllocatedTasks
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AllocatedTask>>> GetAllocatedTask()
        {
            var result = await _context.AllocatedTask.Include(t => t.Task).Include(e => e.Employee).ToListAsync();

            return result;
        }

        // GET: api/AllocatedTasks/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AllocatedTask>> GetAllocatedTask(int id)
        {
            var allocatedTask = await _context.AllocatedTask.FindAsync(id);

            if (allocatedTask == null)
            {
                return NotFound();
            }

            return allocatedTask;
        }

        // PUT: api/AllocatedTasks/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAllocatedTask(int id, AllocatedTask allocatedTask)
        {
            if (id != allocatedTask.AllocatedTaskId)
            {
                return BadRequest();
            }

            _context.Entry(allocatedTask).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AllocatedTaskExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AllocatedTasks
        [HttpPost]
        public async Task<ActionResult<AllocatedTask>> PostAllocatedTask(AllocatedTask allocatedTask)
        {
            _context.AllocatedTask.Add(allocatedTask);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAllocatedTask", new { id = allocatedTask.AllocatedTaskId }, allocatedTask);
        }

        // DELETE: api/AllocatedTasks/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<AllocatedTask>> DeleteAllocatedTask(int id)
        {
            var allocatedTask = await _context.AllocatedTask.FindAsync(id);
            if (allocatedTask == null)
            {
                return NotFound();
            }

            _context.AllocatedTask.Remove(allocatedTask);
            await _context.SaveChangesAsync();

            return allocatedTask;
        }

        private bool AllocatedTaskExists(int id)
        {
            return _context.AllocatedTask.Any(e => e.AllocatedTaskId == id);
        }
    }
}
