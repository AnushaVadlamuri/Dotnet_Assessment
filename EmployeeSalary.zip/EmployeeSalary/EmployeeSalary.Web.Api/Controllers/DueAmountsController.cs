﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EmployeeSalary.Web.Api.Models;

namespace EmployeeSalary.Web.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DueAmountsController : ControllerBase
    {
        private readonly FSPersonnelContext _context;

        public DueAmountsController(FSPersonnelContext context)
        {
            _context = context;
        }

        // GET: api/DueAmounts
        [HttpGet]
        public async Task<ActionResult<IEnumerable<DueAmount>>> GetDueAmount()
        {
            return await _context.DueAmount.ToListAsync();
        }

        // GET: api/DueAmounts/5
        [HttpGet("{id}")]
        public async Task<ActionResult<DueAmount>> GetDueAmount(int id)
        {
            var dueAmount = await _context.DueAmount.FindAsync(id);

            if (dueAmount == null)
            {
                return NotFound();
            }

            return dueAmount;
        }

        // PUT: api/DueAmounts/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutDueAmount(int id, DueAmount dueAmount)
        {
            if (id != dueAmount.DueAmountId)
            {
                return BadRequest();
            }

            _context.Entry(dueAmount).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DueAmountExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/DueAmounts
        [HttpPost]
        public async Task<ActionResult<DueAmount>> PostDueAmount(DueAmount dueAmount)
        {
           var calculatedDueAmount = _context.DueAmount.FromSql("CalculateSalary @fromDate = {0}, @toDate = {1}, @employeeId = {2}",
                dueAmount.FromDate, dueAmount.ToDate, dueAmount.EmployeeId).FirstOrDefault();

            if(calculatedDueAmount != null)
                return CreatedAtAction("GetDueAmount", new { id = calculatedDueAmount.DueAmountId }, calculatedDueAmount);
            else
                return CreatedAtAction("GetDueAmount", new { id = dueAmount.DueAmountId }, dueAmount);
        }

        // DELETE: api/DueAmounts/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<DueAmount>> DeleteDueAmount(int id)
        {
            var dueAmount = await _context.DueAmount.FindAsync(id);
            if (dueAmount == null)
            {
                return NotFound();
            }

            _context.DueAmount.Remove(dueAmount);
            await _context.SaveChangesAsync();

            return dueAmount;
        }

        private bool DueAmountExists(int id)
        {
            return _context.DueAmount.Any(e => e.DueAmountId == id);
        }
    }
}
