﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EmployeeSalary.Web.Api.Models;

namespace EmployeeSalary.Web.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeEffortsController : ControllerBase
    {
        private readonly FSPersonnelContext _context;

        public EmployeeEffortsController(FSPersonnelContext context)
        {
            _context = context;
        }

        // GET: api/EmployeeEfforts
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmployeeEffort>>> GetEmployeeEffort()
        {
            return await _context.EmployeeEffort.Include(e => e.Employee).Include(t => t.Task).ToListAsync();
        }

        // GET: api/EmployeeEfforts/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EmployeeEffort>> GetEmployeeEffort(int id)
        {
            var employeeEffort = await _context.EmployeeEffort.Include(e => e.Employee).Include(t => t.Task).FirstOrDefaultAsync(i => i.EffortHoursId == id);

            if (employeeEffort == null)
            {
                return NotFound();
            }

            return employeeEffort;
        }

        // PUT: api/EmployeeEfforts/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEmployeeEffort(int id, EmployeeEffort employeeEffort)
        {
            if (id != employeeEffort.EffortHoursId)
            {
                return BadRequest();
            }

            _context.Entry(employeeEffort).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeeEffortExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EmployeeEfforts
        [HttpPost]
        public async Task<ActionResult<EmployeeEffort>> PostEmployeeEffort(EmployeeEffort employeeEffort)
        {
            _context.EmployeeEffort.Add(employeeEffort);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEmployeeEffort", new { id = employeeEffort.EffortHoursId }, employeeEffort);
        }

        // DELETE: api/EmployeeEfforts/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<EmployeeEffort>> DeleteEmployeeEffort(int id)
        {
            var employeeEffort = await _context.EmployeeEffort.FindAsync(id);
            if (employeeEffort == null)
            {
                return NotFound();
            }

            _context.EmployeeEffort.Remove(employeeEffort);
            await _context.SaveChangesAsync();

            return employeeEffort;
        }

        private bool EmployeeEffortExists(int id)
        {
            return _context.EmployeeEffort.Any(e => e.EffortHoursId == id);
        }
    }
}
