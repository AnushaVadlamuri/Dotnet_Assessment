﻿using System;
using System.Collections.Generic;

namespace EmployeeSalary.Web.Api.Models
{
    public partial class EmployeeRole
    {
        public EmployeeRole()
        {
            Employee = new HashSet<Employee>();
        }

        public int EmployeeRoleId { get; set; }
        public string EmployeeRoleName { get; set; }
        public int RatePerHour { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }

        public virtual ICollection<Employee> Employee { get; set; }
    }
}
