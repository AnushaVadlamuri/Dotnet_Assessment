﻿using System;
using System.Collections.Generic;

namespace EmployeeSalary.Web.Api.Models
{
    public partial class Employee
    {
        public Employee()
        {
            AllocatedTask = new HashSet<AllocatedTask>();
            EmployeeEffort = new HashSet<EmployeeEffort>();
        }

        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public int EmployeeRoleId { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }

        public virtual EmployeeRole EmployeeRole { get; set; }
        public virtual ICollection<AllocatedTask> AllocatedTask { get; set; }
        public virtual ICollection<EmployeeEffort> EmployeeEffort { get; set; }
    }
}
