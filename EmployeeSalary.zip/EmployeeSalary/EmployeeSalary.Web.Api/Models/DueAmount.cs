﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeSalary.Web.Api.Models
{
    public class DueAmount
    {
        public int DueAmountId { get; set; }
        [DataType(DataType.Date)]
        public DateTime FromDate { get; set; }
        [DataType(DataType.Date)]
        public DateTime ToDate { get; set; }
        public int DueAmountValue { get; set; }

        public int EmployeeId { get; set; }
    }
}
