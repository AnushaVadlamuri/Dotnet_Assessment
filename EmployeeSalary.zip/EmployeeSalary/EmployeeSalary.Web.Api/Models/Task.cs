﻿using System;
using System.Collections.Generic;

namespace EmployeeSalary.Web.Api.Models
{
    public partial class Task
    {
        public Task()
        {
            AllocatedTask = new HashSet<AllocatedTask>();
            EmployeeEffort = new HashSet<EmployeeEffort>();
        }

        public int TaskId { get; set; }
        public string TaskName { get; set; }
        public int? ActualHours { get; set; }

        public virtual ICollection<AllocatedTask> AllocatedTask { get; set; }
        public virtual ICollection<EmployeeEffort> EmployeeEffort { get; set; }
    }
}
