﻿using System;
using System.Collections.Generic;

namespace EmployeeSalary.Web.Api.Models
{
    public partial class AllocatedTask
    {
        public int AllocatedTaskId { get; set; }
        public int TaskId { get; set; }
        public int EmployeeId { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }

        public virtual Employee Employee { get; set; }
        public virtual Task Task { get; set; }
    }
}
