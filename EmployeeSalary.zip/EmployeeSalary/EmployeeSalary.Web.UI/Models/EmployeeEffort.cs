﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeSalary.Web.UI.Models
{
    public class EmployeeEffort
    {
        public int EffortHoursId { get; set; }
        public int EmployeeId { get; set; }
        public int TaskId { get; set; }
        [Display(Name = "Effort Hours")]
        [Required]
        public int EffortHours { get; set; }
        [Display(Name ="Effort Date")]
        [DataType(DataType.Date)]
        public DateTime EffortDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public int? RateOnDay { get; set; }

        public virtual Employee Employee { get; set; }
        public virtual Task Task { get; set; }
    }
}
