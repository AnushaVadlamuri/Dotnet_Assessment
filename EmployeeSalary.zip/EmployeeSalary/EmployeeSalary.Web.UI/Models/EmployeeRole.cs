﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeSalary.Web.UI.Models
{
    public class EmployeeRole
    {
        public EmployeeRole()
        {
            Employee = new HashSet<Employee>();
        }

        public int EmployeeRoleId { get; set; }
        [Display(Name = "Employee Role Name")]
        [Required]
        public string EmployeeRoleName { get; set; }
        [Display(Name = "Rate per Hour")]
        public int RatePerHour { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }

        public virtual ICollection<Employee> Employee { get; set; }
    }
}
