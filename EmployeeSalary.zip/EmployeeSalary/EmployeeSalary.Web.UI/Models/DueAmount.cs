﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeSalary.Web.UI.Models
{
    public class DueAmount
    {
        public int DueAmountId { get; set; }
        [DataType(DataType.Date)]
        [Display(Name = "From Date")]
        [Required]
        public DateTime FromDate { get; set; }
        [DataType(DataType.Date)]
        [Display(Name = "To Date")]
        [Required]
        public DateTime ToDate { get; set; }
        public int DueAmountValue { get; set; }
        public virtual Employee Employee { get; set; }
        public int EmployeeId { get; set; }
    }
}
