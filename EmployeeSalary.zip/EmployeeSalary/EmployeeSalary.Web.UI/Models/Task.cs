﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeSalary.Web.UI.Models
{
    public class Task
    {
        public Task()
        {
            AllocatedTask = new HashSet<AllocatedTask>();
            EmployeeEffort = new HashSet<EmployeeEffort>();
        }

        public int TaskId { get; set; }
        [Display(Name ="Task Name")]
        [Required]
        public string TaskName { get; set; }
        [Display(Name = "Actual Hours")]
        [Required]
        public int? ActualHours { get; set; }

        public virtual ICollection<AllocatedTask> AllocatedTask { get; set; }
        public virtual ICollection<EmployeeEffort> EmployeeEffort { get; set; }
    }
}
