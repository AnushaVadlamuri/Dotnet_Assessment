﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using EmployeeSalary.Web.UI.Models;
using EmployeeSalary.Web.UI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using ModelsTask = EmployeeSalary.Web.UI.Models.Task;

namespace EmployeeSalary.Web.UI.Controllers
{
    public class AllocatedTaskController : Controller
    {
        // GET: AllocatedTask
        public ActionResult Index()
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/AllocatedTasks");
            response.EnsureSuccessStatusCode();
            List<AllocatedTask> allocatedTasks = response.Content.ReadAsAsync<List<AllocatedTask>>().Result;

            return View(allocatedTasks);
        }

        // GET: AllocatedTask/Create
        public ActionResult Create()
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/Tasks");
            response.EnsureSuccessStatusCode();
            List<ModelsTask> tasks = response.Content.ReadAsAsync<List<ModelsTask>>().Result;

            ViewBag.TaskId = new SelectList(tasks, "TaskId", "TaskName");

            response = serviceObj.GetResponse("api/Employees");
            response.EnsureSuccessStatusCode();
            List<Employee> employees = response.Content.ReadAsAsync<List<Employee>>().Result;
            ViewBag.EmployeeId = new SelectList(employees, "EmployeeId", "EmployeeName");

            return View();
        }

        // POST: AllocatedTask/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(AllocatedTask allocatedTask)
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();
                allocatedTask.CreatedDate = DateTime.Now;

                HttpResponseMessage response = serviceObj.PostResponse("api/AllocatedTasks", allocatedTask);
                response.EnsureSuccessStatusCode();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AllocatedTask/Edit/5
        public ActionResult Edit(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/AllocatedTasks/" + id);
            response.EnsureSuccessStatusCode();
            AllocatedTask allocatedTask = response.Content.ReadAsAsync<AllocatedTask>().Result;

            response = serviceObj.GetResponse("api/Tasks");
            response.EnsureSuccessStatusCode();
            List<ModelsTask> tasks = response.Content.ReadAsAsync<List<ModelsTask>>().Result;

            response = serviceObj.GetResponse("api/Employees");
            response.EnsureSuccessStatusCode();
            List<Employee> employees = response.Content.ReadAsAsync<List<Employee>>().Result;

            ViewBag.TaskId = new SelectList(tasks, "TaskId", "TaskName", allocatedTask.TaskId);
            ViewBag.EmployeeId = new SelectList(employees, "EmployeeId", "EmployeeName", allocatedTask.EmployeeId);

            return View(allocatedTask);
        }

        // POST: AllocatedTask/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, AllocatedTask allocateTask)
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();
                HttpResponseMessage response = serviceObj.GetResponse("api/AllocatedTasks/" + id);
                response.EnsureSuccessStatusCode();
                AllocatedTask existingAllocatedTask = response.Content.ReadAsAsync<AllocatedTask>().Result;

                allocateTask.ModifiedDate = DateTime.Now;
                allocateTask.AllocatedTaskId = id;
                allocateTask.CreatedDate = existingAllocatedTask.CreatedDate;

                response = serviceObj.PutResponse("api/AllocatedTasks/" + id, allocateTask);
                response.EnsureSuccessStatusCode();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // POST: AllocatedTask/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();
                HttpResponseMessage response = serviceObj.DeleteResponse("api/AllocatedTasks/" + id);
                response.EnsureSuccessStatusCode();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}