﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using EmployeeSalary.Web.UI.Models;
using EmployeeSalary.Web.UI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using ModelsTask = EmployeeSalary.Web.UI.Models.Task;

namespace EmployeeSalary.Web.UI.Controllers
{
    public class EmployeeEffortController : Controller
    {
        // GET: EmployeeEffort
        public ActionResult Index()
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/EmployeeEfforts");
            response.EnsureSuccessStatusCode();
            List<EmployeeEffort> employeeEfforts = response.Content.ReadAsAsync<List<EmployeeEffort>>().Result;

            return View(employeeEfforts);
        }

        // GET: EmployeeEffort/Create
        public ActionResult Create()
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/Tasks");
            response.EnsureSuccessStatusCode();
            List<ModelsTask> tasks = response.Content.ReadAsAsync<List<ModelsTask>>().Result;

            ViewBag.TaskId = new SelectList(tasks, "TaskId", "TaskName");

            response = serviceObj.GetResponse("api/Employees");
            response.EnsureSuccessStatusCode();
            List<Employee> employees = response.Content.ReadAsAsync<List<Employee>>().Result;
            ViewBag.EmployeeId = new SelectList(employees, "EmployeeId", "EmployeeName");

            return View();
        }

        // POST: EmployeeEffort/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(EmployeeEffort employeeEffort)
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();

                HttpResponseMessage response = serviceObj.GetResponse("api/Employees/" + employeeEffort.EmployeeId);
                response.EnsureSuccessStatusCode();
                Employee employee = response.Content.ReadAsAsync<Employee>().Result;

                employeeEffort.CreatedDate = DateTime.Now;
                employeeEffort.RateOnDay = employee.EmployeeRole.RatePerHour;
                response = serviceObj.PostResponse("api/EmployeeEfforts", employeeEffort);
                response.EnsureSuccessStatusCode();


                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeeEffort/Edit/5
        public ActionResult Edit(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/EmployeeEfforts/" + id);
            response.EnsureSuccessStatusCode();
            EmployeeEffort employeeEffort = response.Content.ReadAsAsync<EmployeeEffort>().Result;

            response = serviceObj.GetResponse("api/Tasks");
            response.EnsureSuccessStatusCode();
            List<ModelsTask> tasks = response.Content.ReadAsAsync<List<ModelsTask>>().Result;

            response = serviceObj.GetResponse("api/Employees");
            response.EnsureSuccessStatusCode();
            List<Employee> employees = response.Content.ReadAsAsync<List<Employee>>().Result;

            ViewBag.TaskId = new SelectList(tasks, "TaskId", "TaskName", employeeEffort.TaskId);
            ViewBag.EmployeeId = new SelectList(employees, "EmployeeId", "EmployeeName", employeeEffort.EmployeeId);

            return View(employeeEffort);
        }

        // POST: EmployeeEffort/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, EmployeeEffort employeeEffort)
        {
            try
            {
                employeeEffort.EffortHoursId = id;
                ServiceRepository serviceObj = new ServiceRepository();
                HttpResponseMessage response = serviceObj.GetResponse("api/Employees/" + employeeEffort.EmployeeId);
                response.EnsureSuccessStatusCode();
                Employee employee = response.Content.ReadAsAsync<Employee>().Result;

                employeeEffort.ModifiedDate = DateTime.Now;
                employeeEffort.RateOnDay = employee.EmployeeRole.RatePerHour;
                employeeEffort.EffortHoursId = id;

                response = serviceObj.PutResponse("api/EmployeeEfforts/" + id, employeeEffort);
                response.EnsureSuccessStatusCode();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // POST: EmployeeEffort/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();
                HttpResponseMessage response = serviceObj.DeleteResponse("api/EmployeeEfforts/" + id);
                response.EnsureSuccessStatusCode();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}