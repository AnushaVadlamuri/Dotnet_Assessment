﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using EmployeeSalary.Web.UI.Models;
using EmployeeSalary.Web.UI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EmployeeSalary.Web.UI.Controllers
{
    public class CalculationController : Controller
    {
        // GET: Calculation
        public ActionResult Index()
        {
            return View();
        }

        // GET: Calculation/Create
        public ActionResult Create()
        {
            ServiceRepository serviceObj = new ServiceRepository();

            HttpResponseMessage response = serviceObj.GetResponse("api/Employees");
            response.EnsureSuccessStatusCode();
            List<Employee> employees = response.Content.ReadAsAsync<List<Employee>>().Result;
            ViewBag.EmployeeId = new SelectList(employees, "EmployeeId", "EmployeeName");

            return View();
        }

        // POST: Calculation/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(DueAmount dueAmount, IFormCollection formCollection)
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();

                dueAmount.EmployeeId = Convert.ToInt16(formCollection["EmployeeId"]);

                HttpResponseMessage response = serviceObj.PostResponse("api/DueAmounts", dueAmount);
                response.EnsureSuccessStatusCode();

                var resultDueAmount = response.Content.ReadAsAsync<DueAmount>().Result;

                ViewBag.TotalDueAmount = resultDueAmount.DueAmountValue;

                response = serviceObj.GetResponse("api/Employees");
                response.EnsureSuccessStatusCode();
                List<Employee> employees = response.Content.ReadAsAsync<List<Employee>>().Result;
                ViewBag.EmployeeId = new SelectList(employees, "EmployeeId", "EmployeeName");

                return View();
            }
            catch
            {
                return View();
            }
        }
    }
}