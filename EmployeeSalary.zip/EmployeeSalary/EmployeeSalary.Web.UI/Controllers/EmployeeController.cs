﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using EmployeeSalary.Web.UI.Models;
using EmployeeSalary.Web.UI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EmployeeSalary.Web.UI.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult Index()
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/Employees");
            response.EnsureSuccessStatusCode();
            List<Employee> employees = response.Content.ReadAsAsync<List<Employee>>().Result;

            return View(employees);
        }


        // GET: Employee/Create
        public ActionResult Create()
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/EmployeeRoles");
            response.EnsureSuccessStatusCode();
            List<EmployeeRole> employeeRoles = response.Content.ReadAsAsync<List<EmployeeRole>>().Result;

            ViewBag.EmployeeRoleId = new SelectList(employeeRoles, "EmployeeRoleId", "EmployeeRoleName");

            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employee employee)
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();
                employee.CreatedDate = DateTime.Now;
                HttpResponseMessage response = serviceObj.PostResponse("api/Employees", employee);
                response.EnsureSuccessStatusCode();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/Edit/5
        public ActionResult Edit(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/Employees/" + id);
            response.EnsureSuccessStatusCode();
            Employee employee = response.Content.ReadAsAsync<Employee>().Result;

            response = serviceObj.GetResponse("api/EmployeeRoles");
            response.EnsureSuccessStatusCode();
            List<EmployeeRole> employeeRoles = response.Content.ReadAsAsync<List<EmployeeRole>>().Result;

            ViewBag.EmployeeRoleId = new SelectList(employeeRoles, "EmployeeRoleId", "EmployeeRoleName", employee.EmployeeRoleId);

            return View(employee);
        }

        // POST: Employee/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Employee employee)
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();
                HttpResponseMessage response = serviceObj.GetResponse("api/Employees/" + id);
                response.EnsureSuccessStatusCode();
                Employee existingEmployee = response.Content.ReadAsAsync<Employee>().Result;

                employee.ModifiedDate = DateTime.Now;
                employee.EmployeeId = id;
                employee.CreatedDate = existingEmployee.CreatedDate;

                response = serviceObj.PutResponse("api/Employees/" + id, employee);
                response.EnsureSuccessStatusCode();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        
        // POST: Employee/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();
                HttpResponseMessage response = serviceObj.DeleteResponse("api/Employees/" + id);
                response.EnsureSuccessStatusCode();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}