﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using EmployeeSalary.Web.UI.Models;
using EmployeeSalary.Web.UI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeSalary.Web.UI.Controllers
{
    public class EmployeeRoleController : Controller
    {
        // GET: EmployeeRole
        public ActionResult Index()
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/EmployeeRoles");
            response.EnsureSuccessStatusCode();
            List<Models.EmployeeRole> employeeRoles = response.Content.ReadAsAsync<List<Models.EmployeeRole>>().Result;
            return View(employeeRoles);
        }

        // GET: EmployeeRole/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: EmployeeRole/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(EmployeeRole employeeRole)
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();
                employeeRole.CreatedDate = DateTime.Now;
                HttpResponseMessage response = serviceObj.PostResponse("api/EmployeeRoles", employeeRole);
                response.EnsureSuccessStatusCode();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeeRole/Edit/5
        public ActionResult Edit(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/EmployeeRoles/" + id);
            response.EnsureSuccessStatusCode();
            EmployeeRole employeeRole = response.Content.ReadAsAsync<EmployeeRole>().Result;

            return View(employeeRole);
        }

        // POST: EmployeeRole/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, EmployeeRole employeeRole)
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();
                HttpResponseMessage response = serviceObj.GetResponse("api/EmployeeRoles/" + id);
                response.EnsureSuccessStatusCode();
                EmployeeRole existingEmployeeRoles = response.Content.ReadAsAsync<EmployeeRole>().Result;

                employeeRole.ModifiedDate = DateTime.Now;
                employeeRole.EmployeeRoleId = id;
                employeeRole.CreatedDate = existingEmployeeRoles.CreatedDate;

                response = serviceObj.PutResponse("api/EmployeeRoles/"+id, employeeRole);
                response.EnsureSuccessStatusCode();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // POST: EmployeeRole/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id)
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();
                HttpResponseMessage response = serviceObj.DeleteResponse("api/EmployeeRoles/" + id);
                response.EnsureSuccessStatusCode();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}